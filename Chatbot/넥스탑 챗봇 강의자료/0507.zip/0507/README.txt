week6chatbot
week6py
저번 주에 했던 quizchatbot 복습형 응용파일입니다.

synopses.json
synopsys_dataset
저번 주에 했던 quizchatbot 복습형 응용파일 json데이터입니다.

telegram
텔레그램 연동 기본 예제입니다.

get-json	chat
텔레그램에서 자신이 입력한 채팅을 chat 제이슨데이터 파일에 받아오는 파이썬 명령문입니다.

chatbot-telegram
텔레그램에 웰니스 데이터파일을 가져와서 적용시키는 파이썬 명령문입니다.


최대한 주석처리 해서 이해하기 쉽게 만들어봤어용 ㅎㅎ
화이팅!