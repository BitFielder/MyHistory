package com.example.networksample;

public class Employee {
    private int id;
    private String employee_name;
    private int employee_age;
    private int employee_salary;

    public int getId() {
        return id;
    }

    public String getEmployee_name() {
        return employee_name;
    }

    public int getEmployee_age() {
        return employee_age;
    }

    public int getEmployee_salary() {
        return employee_salary;
    }
}