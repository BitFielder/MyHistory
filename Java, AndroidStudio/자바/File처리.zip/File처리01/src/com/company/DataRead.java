package com.company;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DataRead {
    ArrayList<Student> students;
    String[] subject;
    Scanner keyboard = new Scanner(System.in);



    public DataRead(ArrayList<Student> students) {
        this.students = students;
        subject = new String[] {"국어", "영어", "수학"};
    }

    public int dataRead() throws IOException {
        int count = 0;
        String name, hakbun;
        while (true) {
            Student student = new Student();
            while (true) {
                System.out.printf("%d번째 학생 이름(3글자)은 ? ", count + 1);
                name = keyboard.next();
                if (name.length() == 3)
                    break;
                else {
                    System.err.println("이름을 정확하게 입력하세요");
                    System.in.read();
                }
            }
            while (true) {
                System.out.printf("%s 학생 학번(7글자)은 ? ", name);
                hakbun = keyboard.next();
                if (hakbun.length() == 7)
                    break;
                else {
                    System.err.println("학번을 정확하게 입력하세요");
                    System.in.read();
                }
            }
            int kor = datainput(name, subject[0]);
            int eng = datainput(name, subject[1]);
            int math = datainput(name, subject[2]);
            student.setHakbun(hakbun);
            student.setName(name);
            student.setKor(kor);
            student.setEng(eng);
            student.setMath(math);

            students.add(student);
            count++;
            char answer;
            while (true) {
                System.out.print("계속 입력하시겠습니까 ? (Yes/No) ");
                answer = keyboard.next().charAt(0);
                if (answer == 'y' || answer == 'Y' || answer == 'n' || answer == 'N')
                    break;
                else {
                    System.err.println("응답을 정확하게 입력하세요");
                    System.in.read();
                }
            }
            if (answer == 'N' || answer == 'n') {
                System.out.printf("%d명을 입력하였습니다\n", count);
                break;
            }
        }
        return count;
    }

    private int datainput(String name, String s) throws IOException {
        int jumsu;
        while (true) {
            System.out.printf("%s 학생 %s 성적 입력 : ", name, s);
            jumsu = keyboard.nextInt();
            if (jumsu >= 0 && jumsu <= 100)
                break;
            else {
                System.err.println("점수를 정확하게 입력하세요");
                System.in.read();
            }
        }
        return jumsu;
    }
}
