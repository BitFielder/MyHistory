package com.company;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException {
	    String filename = "..\\data\\student.dat";
        String filename1 = "..\\data\\student1.dat";

        ArrayList<Student> students = new ArrayList<>();

        DataRead dataRead = new DataRead(students);

        int count = dataRead.dataRead();
        System.out.println(count + "개 입력 ");
        ObjectOutputStream output = null;
        PrintWriter system = new PrintWriter(filename1);
        try {
            output = new ObjectOutputStream(new FileOutputStream(filename));
            output.writeObject(students);
            for (int i = 0; i < count; i++) {
                String fomat = String.format("%7s %3s %03d %03d %03d%n",
                        students.get(i).getHakbun(), students.get(i).getName(),
                        students.get(i).getKor(), students.get(i).getEng(),
                        students.get(i).getMath());
                system.print(fomat);
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
        try {
            output.close();
            system.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
