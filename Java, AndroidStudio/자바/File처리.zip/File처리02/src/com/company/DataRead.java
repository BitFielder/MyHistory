package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DataRead {
    Student[] students;

    public DataRead(Student[] students) {
        this.students = students;
    }

    public int dataRead(String filename) throws IOException {
        //BufferedReader reader = new BufferedReader(new FileReader(filename));
        Scanner scanner = new Scanner(new FileReader(filename));
        int count = 0;
      //  String line;
        while (scanner.hasNextLine()) {
           Scanner temp = new Scanner(scanner.nextLine());
           students[count].setHakbun(temp.next());
           students[count].setName(temp.next());
           students[count].setKor(temp.nextInt());
           students[count].setEng(temp.nextInt());
           students[count].setMath(temp.nextInt());
           count++;
        }
        return count;
    }
}
