package com.company;

import java.io.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException {
        String filename1 = "..\\data\\student1.dat";
        Student[] students = new Student[100];
        for (int i = 0; i < 100; i++)
            students[i]= new Student();

        DataRead dataRead = new DataRead(students);
        int count = dataRead.dataRead(filename1);


        Output output = new Output(students);
        output.display(count);


    }
}
