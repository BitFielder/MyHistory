package com.company;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Output {
    Student[] students;
    String filename = "..\\data\\student.rpt";



    public Output(Student[] students) {
        this.students = students;
    }


    void display(int count) {
        PrintWriter output = null;
        try {
            output = new PrintWriter(filename);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        for (int i = 0; i < count; i++) {

            System.out.println(students[i].toString());
            output.println(students[i].toString());
        }
        output.close();
    }
}
