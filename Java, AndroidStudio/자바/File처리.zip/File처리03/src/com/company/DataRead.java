package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DataRead {
    ArrayList<Student> students;

    public DataRead(ArrayList<Student> students) {
        this.students = students;
    }

    public int dataRead(String filename) throws ClassNotFoundException, IOException {
        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(filename));
        ArrayList list = (ArrayList) inputStream.readObject();
        int count = list.size();

        for (int i = 0; i < count; i++) {
           students.add((Student) list.get(i));
        }
        return count;
    }
}
