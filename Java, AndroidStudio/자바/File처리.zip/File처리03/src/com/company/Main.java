package com.company;

import java.io.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        String filename1 = "..\\data\\student.dat";
        ArrayList<Student> students = new ArrayList<>();




        DataRead dataRead = new DataRead(students);
        int count = dataRead.dataRead(filename1);


        Output output = new Output(students);
        output.display(count);


    }
}
