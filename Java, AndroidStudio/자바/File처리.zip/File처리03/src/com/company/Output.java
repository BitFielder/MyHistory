package com.company;

import java.util.ArrayList;

public class Output {
    ArrayList<Student> students;

    public Output(ArrayList<Student> students) {
        this.students = students;
    }

    void display(int count) {
        for (int i = 0; i < count; i++)
        System.out.println(students.get(i).toString());
    }
}
