package com.company;

public class Compute {
    Student[] students;

    public Compute(Student[] students) {
        this.students = students;
    }

    public void sort(int size) {
        Student temp;
        for (int i = 0; i < size -1; i++) {
            for (int j = i+1; j < size; j++) {
                if (students[i].sum() < students[j].sum()) {
                    temp = students[j];
                    students[j] = students[i];
                    students[i] = temp;
                }
            }
        }
    }

    public void rank(int size) {
        for (int i = 0; i < size; i++)
            students[i].setRank(i+1);
        for (int i = 0;i <size -1; i++)
           if (students[i].sum() == students[i +1].sum())
               students[i+1].setRank(students[i].getRank());
    }
}
