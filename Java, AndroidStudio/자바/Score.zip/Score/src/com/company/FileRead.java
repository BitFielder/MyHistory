package com.company;

import java.io.*;
import java.util.Scanner;

public class FileRead {
    private String path;
    private Student[] students;

    public FileRead(String path, Student[] students) {
        this.path = path;
        this.students = students;
    }

    public int reader() {
        File file = new File(path);
        int i = 0;
        if (file.exists()) {
            try {
                BufferedReader reader = new BufferedReader(new FileReader(file));
                String line;
                while ((line = reader.readLine()) != null){
                    Scanner scanner = new Scanner(line);
                    students[i].setHakbun(scanner.next());
                    students[i].setName(scanner.next());
                    students[i].setKor(scanner.nextInt());
                    students[i].setEng(scanner.nextInt());
                    students[i].setMath(scanner.nextInt());
                    i++;
                    if (i >= students.length) {
                        System.out.println("파일의 크기가 너무 커요");
                        System.exit(-1);
                    }
                }
                reader.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

        } else {
            System.out.println("파일이 존재하지 않아요");
        }
        return i;
    }
}
