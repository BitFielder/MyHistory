package com.company;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;

public class FileWrite {
    private String path;
    static String[] subject = {"국어", "영어", "수학"};

    public FileWrite(String path) {
        this.path = path;
    }

    public void input() {
        boolean flag = false;
        Scanner keyboard = new Scanner(System.in);
        String name, hakbun;
        int[] score = new int[subject.length];
        PrintWriter writer = null;


        File file = new File(path);
        if (file.exists()) {
            System.out.printf("%s 파일이 존재합니다\n", file);
            System.out.print("새롭게 생성할까요?(Yes/No) ");
            char answer = keyboard.next().charAt(0);
            if (answer == 'Y' || answer == 'y')
                flag = false;
            else
                flag = true;
        }
        try {
           writer = new PrintWriter(new FileWriter(file, flag));
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.print("몇명의 학생을 입력하시겠습니까 ? ");
        int num = keyboard.nextInt();
        for (int i = 0; i < num; i++) {
            while (true) {
                System.out.printf("(%d/%d) 번째 학생 이름은 ? ", i+1, num);
                name = keyboard.next();
                if (name.length() == 3)
                    break;
                else {
                    System.err.print("이름 입력 오류");
                    try {
                        System.in.read();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            while (true) {
                System.out.printf("%s 학생의 학번 입력 ", name);
                hakbun = keyboard.next();
                if (hakbun.length() == 7)
                    break;
                else {
                    System.err.print("학번 입력 오류");
                    try {
                        System.in.read();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            int j = 0;
            while (j < subject.length) {
                System.out.printf("%s 학생의 %s 성적 입력 ", name, subject[j]);
                score[j] = keyboard.nextInt();
                if (score[j] >= 0 && score[j] <= 100)
                    j++;
                else {
                    System.err.print("성적 입력 오류");
                    try {
                        System.in.read();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }
            writer.printf("%7s %3s %03d %03d %03d%n", hakbun, name, score[0], score[1], score[2]);
        }
        System.out.println("파일 생성 성공");
        writer.close();
    }
}
