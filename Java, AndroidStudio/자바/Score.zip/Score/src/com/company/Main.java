package com.company;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        int count = 0;
        String path = ".\\data\\student.txt";
        String outputfile = ".\\data\\student.rpt";

        ArrayList<Student> students = new ArrayList<>();


        Scanner keyboard = new Scanner(System.in);
        File file = new File(path);
        if (file.exists()) {
            FileRead read = new FileRead(path, students);
            count = read.reader();
            System.out.printf("%d개의 데이터가 있습니다\n", count);
        }

        while (true) {
            System.out.println("******* 성적처리 프로그램 *************");
            System.out.println("\t\t1.자료 파일로 저장하기");
            System.out.println("\t\t2.자료 로딩");
            System.out.println("\t\t3.자료 처리");
            System.out.println("\t\t4.자료 처리(File)");
            System.out.println("\t\t5.자료 Noterpad 보기");
            System.out.println("\t\t6.자료 Noterpad 보기");
            System.out.println("\t\t7.학번 검색 ");
            System.out.println("\t\t0.종료");
            System.out.println("*************************************");
            System.out.print("\t\t\t 메뉴를 선택하세요 ");
            switch (keyboard.nextInt()) {
                case 1:
                    FileWrite write = new FileWrite(path);
                    write.input();
                    break;
                case 2:
                    FileRead read = new FileRead(path, students);
                    count = read.reader();
                    System.out.printf("%d개의 데이터가 있습니다\n", count);
                    break;
                case 3 :
                    if (count == 0) {
                        System.out.println("Data가 없습니다");
                    } else {
                        Compute compute = new Compute(students);
                        compute.sort(count);
                        compute.rank(count);
                    }
                    Output output = new Output(students);
                    output.display(count);
                    break;
                case 4 :
                    try {
                        PrintWriter writer = new PrintWriter(new FileWriter(outputfile));
                        Output output1 = new Output(students);
                        output1.display(writer, count);
                        writer.close();
                        System.out.println("파일 생성 완료");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 5 :
                    try {
                        Runtime.getRuntime().exec("Notepad.exe " + path);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 6 :
                    try {
                        Runtime.getRuntime().exec("Notepad.exe " + outputfile);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    break;
                case 7 :
                    Search search = new Search(students);
                    search.find();
                    break;
                case 0:
                    System.out.println("프로그램을 종료 합니다");
                    System.exit(0);
                default:
                    System.out.println("다시 입력하세요");
                    break;
            }
        }
    }
}
