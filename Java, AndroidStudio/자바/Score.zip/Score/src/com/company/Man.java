package com.company;

import java.io.PrintWriter;

public class Man {
    private String hakbun;
    private String name;

    public Man() {
    }

    public Man(String hakbun, String name) {
        this.hakbun = hakbun;
        this.name = name;
    }

    public String getHakbun() {
        return hakbun;
    }

    public void setHakbun(String hakbun) {
        this.hakbun = hakbun;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void display() {
        System.out.printf("%7s %3s", hakbun, name);
    }
    public void display(PrintWriter writer) {
        writer.printf("%7s %3s", hakbun, name);
    }
}
