package com.company;

import java.io.PrintWriter;

public class Output {
    Student[] students;


    String format = String.format(" 학번   이름  %s %s %s  총점  평균 석차",
            FileWrite.subject[0], FileWrite.subject[1], FileWrite.subject[2]);

    public Output(Student[] students) {
        this.students = students;
    }



    public void display(PrintWriter writer, int size) {
        line(writer);
        writer.println(format);
        line(writer);
        for (int i = 0; i < size; i++)
            students[i].display(writer);
        line(writer);
    }

    private void line(PrintWriter writer) {
        writer.println("*************************************");
    }

    public void display(int size) {
        line();
        System.out.println(format);
        line();
        for (int i = 0; i < size; i++)
            students[i].display();
        line();
    }

    private void line() {
        System.out.println("*************************************");
    }
}
