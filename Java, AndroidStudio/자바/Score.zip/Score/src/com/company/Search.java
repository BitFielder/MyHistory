package com.company;

public class Search {
    Student[] students;

    public Search(Student[] students) {
        this.students = students;
    }

    public void find() {

    }
}
