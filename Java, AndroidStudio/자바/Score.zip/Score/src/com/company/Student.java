package com.company;

import java.io.PrintWriter;

public class Student extends Man{
    private int kor;
    private int eng;
    private int math;
    private int rank;

    public Student() {
        super();
    }

    public Student(String hakbun, String name, int kor, int eng, int math) {
        super(hakbun, name);
        this.kor = kor;
        this.eng = eng;
        this.math = math;
    }

    public int sum() {
        return kor + eng + math;
    }

    public float avg() {
        return sum()/ 3.0f;
    }

    public int getKor() {
        return kor;
    }

    public void setKor(int kor) {
        this.kor = kor;
    }

    public int getEng() {
        return eng;
    }

    public void setEng(int eng) {
        this.eng = eng;
    }

    public int getMath() {
        return math;
    }

    public void setMath(int math) {
        this.math = math;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public int getRank() {
        return rank;
    }

    public void display() {
        super.display();
        System.out.printf(" %03d %03d %03d %3d %5.2f %2d\n",
                kor, eng, math, sum(), avg(), rank);
    }

    public void display(PrintWriter writer) {
        super.display(writer);
        writer.printf(" %03d %03d %03d %3d %5.2f %2d\n",
                kor, eng, math, sum(), avg(), rank);
    }
}
