package pyjun;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class DataRead {
    ArrayList<Employee> employees;
    Scanner keyboard = new Scanner(System.in);

    public DataRead(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public int dataRead() throws IOException {
        int count = 0;
        String bunho, name;
        while (true) {
           // Employee employee = new Employee();
            while (true) {
                System.out.printf("%d번째 사원 이름(3글자)은 ? ", count + 1);
                name = keyboard.next();
                if (name.length() == 3)
                    break;
                else {
                    System.err.println("이름을 정확하게 입력하세요");
                    System.in.read();
                }
            }
            while (true) {
                System.out.printf("%s 사원 사번(4글자)은 ? ", name);
                bunho = keyboard.next();
                if (bunho.length() == 4)
                    break;
                else {
                    System.err.println("사번을 정확하게 입력하세요");
                    System.in.read();
                }
            }

            count++;
            char answer;
            while (true) {
                System.out.print("계속 입력하시겠습니까 ? (Yes/No) ");
                answer = keyboard.next().charAt(0);
                if (answer == 'y' || answer == 'Y' || answer == 'n' || answer == 'N')
                    break;
                else {
                    System.err.println("응답을 정확하게 입력하세요");
                    System.in.read();
                }
            }
            if (answer == 'N' || answer == 'n') {
                System.out.printf("%d명을 입력하였습니다\n", count);
                break;
            }
        }
        return count;
    }
}