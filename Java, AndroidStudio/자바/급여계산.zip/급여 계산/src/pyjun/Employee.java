package pyjun;

import java.io.Serializable;

public class Employee implements Serializable {
    private static final long serialVersionUID = 12345L;
    private String bunho;
    private String name;
    private int hobong;
    private int sudang;

    public Employee() {

    }

    public Employee(String bunho, String name, char hobong, int sudang) {
        this.bunho = bunho;
        this.name = name;
        this.hobong = hobong;
        this.sudang = sudang;
    }

    public String getBunho() {
        return bunho;
    }

    public void setBunho(String bunho) {
        this.bunho = bunho;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHobong() {
        return hobong;
    }

    public void setHobong(char hobong) {
        this.hobong = hobong;
    }

    public int getSudang() {
        return sudang;
    }

    public void setSudang(int sudang) {
        this.sudang = sudang;
    }
}
