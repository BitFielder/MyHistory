package pyjun;

import java.io.IOException;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) throws IOException {
        String filename = "C\\Temp\\employee.txt";

        ArrayList<Employee> employees = new ArrayList<>();

        DataRead dataRead = new DataRead(employees);
        int count = dataRead.dataRead();

        Output output = new Output(employees);
        output.display();
    }
}
