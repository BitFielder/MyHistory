package pyjun;

import java.util.ArrayList;

public class Output {
    private final ArrayList<Employee> employees;
    String filename1 = "..\\data\\employee1.txt";

    public Output(ArrayList<Employee> employees) {
        this.employees = employees;
    }

    public void display() {
    }
}
