package pyjun;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

public class DataRead {
    Employee[] employees;

    public DataRead(Employee[] employees) {
        this.employees = employees;
    }

    public int dataRead(String filename) throws FileNotFoundException {
        Scanner scanner = new Scanner(new FileReader(filename));
        int count = 0;
        while (scanner.hasNextLine()) {
            Scanner temp = new Scanner(scanner.nextLine()).useDelimiter("(\r\n)");
            employees[count].setBunho(temp.next());
            employees[count].setName(temp.next());
            employees[count].setHobong(temp.nextInt());
            employees[count].setSudang(temp.nextInt());
            count++;
        }
        return count;
    }
}
