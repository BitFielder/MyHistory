package pyjun;

import java.io.Serializable;

public class Employee implements Serializable {
    private static final long serialVersionUID = 12345L;
    private String bunho;
    private String name;
    private int hobong;
    private int sudang;

    public Employee() {
    }

    public Employee(String bunho, String name, int hobong, int sudang) {
        this.bunho = bunho;
        this.name = name;
        this.hobong = hobong;
        this.sudang = sudang;
    }

    public String getBunho() {
        return bunho;
    }

    public void setBunho(String bunho) {
        this.bunho = bunho;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getHobong() {
        return hobong;
    }

    public void setHobong(int hobong) {
        this.hobong = hobong;
    }

    public int getSudang() {
        return sudang;
    }

    public void setSudang(int sudang) {
        this.sudang = sudang;
    }

    public int money(){
        int salary = 0;
        switch (hobong){
            case 1:
                salary = 1650000;
                break;
            case 2:
                salary = 1680000;
                break;
            case 3:
                salary = 1700000;
                break;
            case 4:
                salary = 1720000;
                break;
            case 5:
                salary = 1750000;
                break;
        }
        return salary;
    }

    public int provision(){
        return (sudang + money());
    }

    public int taxation(){
        int tax = 0;
        if (provision() < 1700000){
            tax = (provision() * (5/100));
        }else if (provision() >= 1700000 && provision() >= 2300000){
            tax = (provision() * (8/100));
        }else {
            tax = (provision() * (10/100));
        }
        return tax;
    }

    private int NET(){
        return (provision() - taxation());
    }

    @Override
    public String toString() {
        return  bunho + name + hobong + sudang + String.format("%9d",money()) +
                String.format("%9d",provision()) + String.format("%9d",taxation()) +
                String.format("%9d",NET());
    }
}
