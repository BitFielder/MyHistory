package pyjun;

import java.io.FileNotFoundException;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        String filename1 = "C:\\Temp\\employee.txt";
        Employee[] employees = new Employee[10];
        for (int i = 0; i < 10; i++){
            employees[i] = new Employee();
        }

        DataRead dataRead = new DataRead(employees);
        int count = dataRead.dataRead(filename1);

        Output output = new Output(employees);
        output.display(count);
    }
}
