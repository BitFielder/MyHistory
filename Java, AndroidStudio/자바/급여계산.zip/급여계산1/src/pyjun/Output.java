package pyjun;

public class Output {
    Employee[] employees;
    String filename = "C:\\Temp\\employee1.rpt";

    public Output(Employee[] employees) {
        this.employees = employees;
    }

    private void line(){
        System.out.println("********************************************************************************");
    }

    public void display(int count) {
        System.out.println("                                  급여 처리");
        line();
        System.out.println("  사번   이름  호봉  기본급   급여액   세금     지급액");
        line();
        for (int i = 0; i < count; i++){
            System.out.print(employees[i].toString());
        }
        line();
    }
}
