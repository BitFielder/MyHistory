package pyjun;

public class Employee extends Man{
    private int hobong;
    private int sudang;

    public Employee() {super();}

    public Employee(String bunho, String name, int hobong, int sudang) {
        super(bunho, name);
        this.hobong = hobong;
        this.sudang = sudang;
    }
}
