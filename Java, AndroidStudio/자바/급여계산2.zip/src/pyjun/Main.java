package pyjun;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        int count = 0;
        String filename = "C:\\Temp\\employee.txt";
        String filename1 = "C:\\Temp\\employee.rpt";

        ArrayList<Employee> employees = new ArrayList<>();
    }
}
