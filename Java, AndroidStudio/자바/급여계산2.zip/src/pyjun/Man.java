package pyjun;

import java.io.PrintWriter;

public class Man {
    private String bunho;
    private String name;

    public Man() {
    }

    public Man(String bunho, String name) {
        this.bunho = bunho;
        this.name = name;
    }

    public String getBunho() {
        return bunho;
    }

    public void setBunho(String bunho) {
        this.bunho = bunho;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void display() {
        System.out.printf("%4s %3s", bunho, name);
    }
    public void display(PrintWriter writer) {
        writer.printf("%4s %3s", bunho, name);
    }
}