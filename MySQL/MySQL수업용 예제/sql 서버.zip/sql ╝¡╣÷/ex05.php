<?php
	$m=5;
	switch($m){
	case 5: echo "{$m}월은 봄"; break;
	case 8: echo "{$m}월은 여름"; break;
	case 10: echo "{$m}월은 가을"; break;
	case 12: echo "{$m}월은 겨울"; break;
	default: echo "다시 입력";	}
	?>