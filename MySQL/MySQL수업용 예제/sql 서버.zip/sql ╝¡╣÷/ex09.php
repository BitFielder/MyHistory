<html>
	<head>
		<meta charset="utf-8">
	</head>
	<body>
	<?php
		$school = $_POST["school"];
		$dept = $_POST["dept"];
		echo "학교 : $school <br/>학과 : $dept";
		?>
	</body>
</html>
