<html>
	<head><title>글상자</title>
	<meta charset = "utf-8"></head>
	<body>
		<?php
			$memo = $_POST["memo"];
			echo "메모 : $memo";
		?>
	</body>
	
</html>