<html>
	<head><title>라디오버튼</title>
	<meta charset = "utf-8"></head>
	<body>
		<?php
			$addr = $_POST["addr"];
			$dept = $_POST["dept"];
			echo "거주지 : $addr, 학과 : $dept";
		?>
	</body>
	
</html>