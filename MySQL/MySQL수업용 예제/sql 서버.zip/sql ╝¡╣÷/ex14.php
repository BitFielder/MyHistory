<html>
	<head><title>체크박스</title>
	<meta charset = "utf-8"></head>
	<body>
		<?php
			$address = $_POST["address"];
			echo "거주지역 : $address";
		?>
	</body>
	
</html>