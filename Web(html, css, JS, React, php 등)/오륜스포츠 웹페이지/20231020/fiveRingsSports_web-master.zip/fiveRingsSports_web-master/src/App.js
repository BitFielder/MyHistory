import { Route, Routes } from "react-router";
import Error from "./pages/Error";
import Main from "./pages/Main";
import { ToastContainer } from "react-toastify";
import { useEffect } from "react";
import { useSelector, useDispatch } from "react-redux";

function App() {
  const dispatch = useDispatch();



  return (
    <>
      <ToastContainer />
      <Routes>
        <Route path="/*" element={<Main />} />
        <Route path="/error" element={<Error />} />
        <Route path="*" element={<Error />} />
      </Routes>
    </>
  );
}

export default App;
