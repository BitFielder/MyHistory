// 로그인
export const USER_LOGIN = "USER_LOGIN";
export const SET_TOAST = "SET_TOAST";
export const CLEAR_TOAST = "CLEAR_TOAST";