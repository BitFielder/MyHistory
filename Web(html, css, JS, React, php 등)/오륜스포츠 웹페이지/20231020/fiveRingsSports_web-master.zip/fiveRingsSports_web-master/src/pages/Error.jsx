import React from "react";

const Error = (props) => (
  <div>
    <h1>Error</h1>
    <p>대충 에러페이지로 칩시다~</p>
  </div>
);
export default Error;
