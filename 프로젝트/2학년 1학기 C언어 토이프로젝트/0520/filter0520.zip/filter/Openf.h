
#define ErrCI 1
#define ErrCO 2
#define bufSize 250
FILE *Openf(FILE *a, char *n, char *m);