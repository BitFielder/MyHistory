
char *hexadump(char *t4, char *inbuf);