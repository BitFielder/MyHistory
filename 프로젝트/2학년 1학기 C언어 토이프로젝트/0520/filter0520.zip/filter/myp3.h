
char *hyhmyp3(char *t3, char *inbuf);
