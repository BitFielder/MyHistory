
char *yycmyp2(char *t2, char *inbuf);
