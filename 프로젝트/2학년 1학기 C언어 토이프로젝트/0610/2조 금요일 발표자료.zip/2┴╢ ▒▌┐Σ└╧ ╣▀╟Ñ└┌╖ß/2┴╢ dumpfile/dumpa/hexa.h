#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int HexaDump(FILE *i,FILE *o,char n);