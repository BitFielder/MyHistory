// script.js

// 오늘 날짜를 가져오는 함수
function getToday() {
  var now = new Date();
  var year = now.getFullYear();
  var month = now.getMonth() + 1;
  var day = now.getDate();
  return year + "-" + month + "-" + day;
}

// 오늘과 총 접속자 수를 저장하는 변수
var todayCount = 0;
var totalCount = 0;

// 페이지가 로드될 때 실행되는 함수
window.onload = function () {
  // 오늘과 총 접속자 수를 가져오기
  var storedToday = localStorage.getItem("today");
  var storedTotal = localStorage.getItem("total");

  // 저장된 값이 있으면 변수에 할당
  if (storedToday) {
    todayCount = parseInt(storedToday);
  }
  if (storedTotal) {
    totalCount = parseInt(storedTotal);
  }

  // 오늘 접속자 수와 총 접속자 수를 표시
  document.getElementById("todayCount").textContent = todayCount;
  document.getElementById("totalCount").textContent = totalCount;
};

// 페이지를 닫을 때 실행되는 함수
window.onbeforeunload = function () {
  // 오늘과 총 접속자 수를 로컬 스토리지에 저장
  localStorage.setItem("today", todayCount);
  localStorage.setItem("total", totalCount);
};

// 페이지에 접속했을 때 실행되는 함수
function pageLoaded() {
  // 오늘 접속자 수 증가
  todayCount++;

  // 총 접속자 수 증가
  totalCount++;

  // 오늘 접속자 수와 총 접속자 수를 업데이트
  document.getElementById("todayCount").textContent = todayCount;
  document.getElementById("totalCount").textContent = totalCount;
}



var emailtext = "ashe152@kbu.ac.kr";

// 복사 버튼 클릭 이벤트 리스너 등록
function copybutton() {
  // 문자열 복사
  copyToClipboard(emailtext);

  // 말풍선 보이기
  showtextbox1();
};

// 문자열 복사 함수
function copyToClipboard(text) {
  var textarea = document.createElement("textarea");
  textarea.value = text;
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  document.body.removeChild(textarea);
}

// 말풍선 보이기 함수
function showtextbox1() {
  var textbox1 = document.getElementById("textbox1");
  textbox1.classList.add("show"); // show 클래스 추가

  // 일정 시간 후에 말풍선 숨기기
  setTimeout(function () {
    textbox1.classList.remove("show"); // show 클래스 제거
  }, 2000);
}